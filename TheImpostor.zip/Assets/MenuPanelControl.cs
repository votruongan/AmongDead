﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MenuPanelControl : MonoBehaviour
{
    public void SetActive(bool val){
        this.gameObject.SetActive(val);
    }
}
