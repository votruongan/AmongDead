public class StaticTextBase
{

    public static StaticTextBase instance;
}