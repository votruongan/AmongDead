﻿
namespace V_ObjectSystem {

    public interface V_IDestroySelf {

        // Clean up code
        void DestroySelf();

    }

}