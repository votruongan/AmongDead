﻿
namespace V_ObjectSystem {

    public interface V_IObjectActiveLogic {

        void Update(float deltaTime);

    }

}